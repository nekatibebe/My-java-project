   import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// --- 1. JAVA GENERICS (Record Storage) ---
class RecordManager<T> {
    private List<T> records = new ArrayList<>();
    public void addRecord(T record) { records.add(record); }
    public List<T> getRecords() { return records; }
}

// --- 2. INTERFACE (Payment Strategy) ---
interface Payment {
    void pay(double amount);
}

// --- 3. ABSTRACT CLASS (User Template) ---
abstract class User {
    protected int userId;
    protected String name, email;
    protected boolean isLoggedIn = false;

    public User(int userId, String name, String email) {
        this.userId = userId;
        this.name = name;
        this.email = email;
    }

    public void login() {
        isLoggedIn = true;
        System.out.println("\n[System] User " + name + " logged in.");
    }

    public void logout() {
        isLoggedIn = false;
        System.out.println("[System] User " + name + " logged out.");
    }

    public abstract void displayRole();
}

// --- 4. INHERITANCE (Passenger) ---
class Passenger extends User {
    private String passportNumber;

    public Passenger(int userId, String name, String email, String passport) {
        super(userId, name, email);
        this.passportNumber = passport;
    }

    @Override
    public void displayRole() { System.out.println("Role: Passenger"); }
    public String getName() { return name; }
    public boolean getStatus() { return isLoggedIn; }
}

// --- 5. ENCAPSULATION (Flight Logic) ---
class Flight {
    private String id, origin, destination, type;
    private int seatsAvailable;
    private double basePrice;

    public Flight(String id, String org, String dest, String type, int seats, double price) {
        this.id = id; this.origin = org; this.destination = dest;
        this.type = type; this.seatsAvailable = seats; this.basePrice = price;
    }

    public boolean checkAvailability() { return seatsAvailable > 0; }
    public void updateSeats() { if (seatsAvailable > 0) seatsAvailable--; }
    
    // Logic for Business vs Economic price
    public double calculatePrice(int classType) {
        return (classType == 1) ? basePrice * 1.8 : basePrice; // Business is 80% more expensive
    }

    public String getInfo(int classType) {
        String className = (classType == 1) ? "Business" : "Economic";
        return String.format("%s to %s [%s Class] - Total: $%.2f", origin, destination, className, calculatePrice(classType));
    }

    public String getDestination() { return destination; }
    public String getType() { return type; }
}

// --- 6. POLYMORPHISM (Payment Types) ---
class CreditCardPayment implements Payment {
    private String card;
    public CreditCardPayment(String card) { this.card = card; }
    public void pay(double amt) { System.out.println("Paid $" + amt + " via Credit Card."); }
}

class MobilePayment implements Payment {
    private String phone;
    public MobilePayment(String phone) { this.phone = phone; }
    public void pay(double amt) { System.out.println("Paid $" + amt + " via Mobile (+251)."); }
}

class Booking {
    public void createBooking(Passenger p, Flight f, Payment pay, int classType) {
        if (!p.getStatus()) return;
        if (f.checkAvailability()) {
            double finalPrice = f.calculatePrice(classType);
            pay.pay(finalPrice);
            f.updateSeats();
            System.out.println("\n--- TICKET CONFIRMED ---");
            System.out.println("Passenger: " + p.getName());
            System.out.println("Details: " + f.getInfo(classType));
            System.out.println("------------------------");
        } else {
            System.out.println("Flight is full!");
        }
    }
}

// --- MAIN EXECUTION ---
public class AirportSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        RecordManager<Flight> flightRepo = new RecordManager<>();

        // National Destinations (4)
        flightRepo.addRecord(new Flight("NAT01", "ADD", "Bahir Dar", "National", 5, 100));
        flightRepo.addRecord(new Flight("NAT02", "ADD", "Hawassa", "National", 5, 110));
        flightRepo.addRecord(new Flight("NAT03", "ADD", "Jimma", "National", 5, 90));
        flightRepo.addRecord(new Flight("NAT04", "ADD", "Mekele", "National", 5, 130));

        // International Destinations (4)
        flightRepo.addRecord(new Flight("INT01", "ADD", "Dubai", "International", 10, 500));
        flightRepo.addRecord(new Flight("INT02", "ADD", "Nairobi", "International", 10, 350));
        flightRepo.addRecord(new Flight("INT03", "ADD", "New York City", "International", 10, 1200));
        flightRepo.addRecord(new Flight("INT04", "ADD", "London", "International", 10, 950));

        System.out.println("=== AIRLINE REGISTRATION ===");
        
        // Strict Validations
        String name;
        while (true) {
            System.out.print("Name: "); name = sc.nextLine();
            if (name.matches("^[a-zA-Z\\s]+$")) break;
            System.out.println("Invalid Name!");
        }

        String email;
        while (true) {
            System.out.print("Email: "); email = sc.nextLine();
            if (email.toLowerCase().endsWith("@gmail.com")) break;
            System.out.println("Invalid Email!");
        }

        String passport;
        while (true) {
            System.out.print("Passport (9 chars): "); passport = sc.nextLine();
            if (passport.length() == 9) break;
            System.out.println("Invalid Passport!");
        }

        Passenger passenger = new Passenger(202, name, email, passport);
        passenger.login();

        // Step 1: Flight Type
        System.out.println("\n1. National\n2. International\nSelect Category: ");
        int cat = sc.nextInt(); sc.nextLine();
        String selectedType = (cat == 1) ? "National" : "International";

        // Step 2: Destination
        System.out.println("\nDestinations:");
        List<Flight> choices = new ArrayList<>();
        int i = 1;
        for (Flight f : flightRepo.getRecords()) {
            if (f.getType().equals(selectedType)) {
                choices.add(f);
                System.out.println(i++ + ". " + f.getDestination());
            }
        }
        System.out.print("Choice: ");
        int fIdx = sc.nextInt() - 1;

        // Step 3: Class Selection
        System.out.println("\nSelect Class:\n1. Business Class (1.8x Price)\n2. Economic Class (Base Price)");
        int classChoice = sc.nextInt(); sc.nextLine();

        Flight selectedFlight = choices.get(fIdx);

        // Step 4: Payment
        System.out.println("\nPayment:\n1. Credit Card\n2. Mobile");
        int pType = sc.nextInt(); sc.nextLine();
        Payment payment;
        if (pType == 1) {
            System.out.print("16-digit Card: ");
            payment = new CreditCardPayment(sc.nextLine());
        } else {
            String phone;
            while (true) {
                System.out.print("Phone (+2519... followed by 8 digits): ");
                phone = sc.nextLine();
                if (phone.matches("^\\+2519\\d{8}$")) break;
                System.out.println("Invalid Format!");
            }
            payment = new MobilePayment(phone);
        }

        // Final Step: Booking
        new Booking().createBooking(passenger, selectedFlight, payment, classChoice);

        passenger.logout();
        sc.close();
    }
}
